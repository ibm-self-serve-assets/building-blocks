---
name: data-ingestion-unstructured
description: IBM Bob guidance for IBM watsonx.data integration — Unstructured Data Integration (UDI), including document extraction, chunking, metadata enrichment, IBM COS sources, IBM watsonx.ai embeddings, and supported retrieval targets.
---

# IBM Unstructured Data Integration

## Product scope

Use **IBM watsonx.data integration — Unstructured Data Integration** for preparing unstructured enterprise content for AI and retrieval.

## Rules

- Keep UDI separate from DataStage batch ETL, Data Replication, Aspera file sync, and event streaming.
- Prefer IBM UDI extraction/processing capabilities and IBM Docling where a code-level document conversion step is required.
- Keep embedding model selection configurable. Current example: `ibm/granite-embedding-278m-multilingual`.
- Confirm supported document formats, operators, targets, and deployment prerequisites in current IBM documentation.
- Do not invent UDI APIs, connectors, operator names, or environment variables.
- Keep credentials out of source control and TLS verification enabled.

## Workflow

1. Identify content sources, formats, volume, metadata, security, and target.
2. Confirm UDI support in the deployed IBM environment.
3. Configure extraction/OCR and document structure handling.
4. Configure chunking and metadata preservation.
5. Configure IBM watsonx.ai embeddings when the target requires vectors.
6. Validate retrieval quality, reprocessing, failures, and lineage/traceability.

## IBM references

- https://www.ibm.com/docs/en/software-hub/5.4.x?topic=services-watsonxdata-integration
- https://www.ibm.com/docs/en/watsonx/saas?topic=models-supported-embedding
- https://www.ibm.com/docs/en/watsonx/saas?topic=model-foundation-lifecycle
