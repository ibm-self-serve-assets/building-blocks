---
name: data-ingestion-structured
description: IBM-focused guidance for structured ingestion using IBM watsonx.data integration capabilities such as DataStage, StreamSets, and Data Replication. This is a companion skill retained in the existing repository layout; it is not UDI.
---

# Structured Data Ingestion Companion

Use IBM watsonx.data integration capabilities according to workload type:

- **Batch ETL/ELT**: IBM DataStage
- **Streaming ingestion**: IBM StreamSets / IBM streaming capabilities where applicable
- **CDC / near-real-time replication**: IBM Data Replication
- **Target analytics/lakehouse**: IBM watsonx.data

## Rules

1. Do not classify structured CDC, replication, or batch ETL as UDI.
2. Use only product-supported connectors and deployment-specific procedures documented by IBM.
3. Do not invent REST endpoints, connector names, or configuration fields.
4. Keep credentials in environment variables or an approved secrets manager.
5. Validate source/target support, prerequisites, and regional/deployment availability before generating implementation steps.

## IBM references

- IBM watsonx.data integration: https://www.ibm.com/products/watsonx-data-integration
- watsonx.data integration documentation: https://www.ibm.com/docs/en/software-hub/5.4.x?topic=services-watsonxdata-integration
- DataStage integration with watsonx.data: https://cloud.ibm.com/docs/watsonxdata?topic=watsonxdata-dc_integration
