---
name: databand-pipeline-setup
description: IBM-focused guidance for IBM watsonx.data integration Data Observability / Databand-compatible pipeline monitoring, run health, metrics, anomalies, and alerts.
---

# Data Observability Setup

Use this skill for operational observability: pipeline/run health, failures, metrics, anomalies, SLAs, and alerts. Enterprise lineage and impact analysis belong to IBM watsonx.data intelligence.

## Rules

1. Use the APIs/connectors available in the target IBM Data Observability deployment; do not invent endpoint paths.
2. Treat OpenLineage events as operational/lineage metadata where supported, not as proof that Databand is the enterprise lineage graph.
3. Never hard-code credentials; use TLS verification and approved secret handling.
4. Verify current product/version behavior in IBM watsonx.data integration documentation.

## IBM references

- IBM watsonx.data integration: https://www.ibm.com/products/watsonx-data-integration
- watsonx.data integration documentation: https://www.ibm.com/docs/en/software-hub/5.4.x?topic=services-watsonxdata-integration
