---
name: openlineage-instrumentation
description: IBM-focused guidance for OpenLineage instrumentation and ingestion into IBM watsonx.data intelligence for enterprise lineage and impact analysis.
---

# OpenLineage Instrumentation

IBM's current lineage pattern uses OpenLineage as the exchange standard:

- **Producers**: IBM watsonx.data, IBM watsonx.data integration, and supported/custom workloads
- **Consumer / enterprise lineage view**: IBM watsonx.data intelligence
- **Operational observability**: IBM watsonx.data integration — Data Observability (separate concern)

## Rules

1. Generate valid OpenLineage events with stable job, run, input, and output identifiers.
2. Use IBM-supported ingestion/import procedures for watsonx.data intelligence; do not invent REST endpoints.
3. Do not route enterprise lineage through Data Observability/Databand unless a specific supported integration requires it.
4. Keep secrets outside source code and use TLS verification.
5. Verify current supported connectors and OpenLineage behavior in IBM documentation before implementation.

## IBM references

- OpenLineage integration: https://www.ibm.com/docs/en/ws-and-kc?topic=lineage-openlineage-integration
- Data lineage product: https://www.ibm.com/products/watsonx-data-intelligence/data-lineage
- Manta integration with watsonx.data: https://cloud.ibm.com/docs/watsonxdata?topic=watsonxdata-manta_integrate
