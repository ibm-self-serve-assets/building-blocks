---
name: astradb-nosql-design
description: IBM-focused guidance for document/NoSQL applications using the Astra DB service available through IBM watsonx.data.
---

# IBM watsonx.data — Astra DB NoSQL Design

Use Astra DB through IBM watsonx.data for serverless document/table workloads. `astrapy` is the implementation SDK, not the product identity.

## Rules

1. Verify the current Astra DB deployment model and regional availability in IBM documentation.
2. Design collections/tables around workload access patterns and required consistency.
3. Keep credentials outside source code and use TLS verification.
4. Do not invent service endpoints or unsupported SDK capabilities.

## IBM references

- Add Astra DB service: https://www.ibm.com/docs/en/watsonxdata/saas?topic=watsonxdata-adding-astra-db-service
- watsonx.data availability: https://cloud.ibm.com/docs/watsonxdata?topic=watsonxdata-feature_parity_wxd
