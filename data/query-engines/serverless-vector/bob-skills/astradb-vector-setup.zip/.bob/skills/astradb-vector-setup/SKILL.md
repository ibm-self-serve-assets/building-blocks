---
name: astradb-vector-setup
description: IBM-focused guidance for the Astra DB serverless vector service available through IBM watsonx.data, using IBM watsonx.ai embeddings and IBM Cloud Object Storage.
---

# IBM watsonx.data — Astra DB Vector Setup

## Current IBM model example

- Embedding: `ibm/granite-embedding-278m-multilingual`
- Dimension: `768`

## Rules

1. Provision/use Astra DB through IBM watsonx.data for this building block.
2. Verify current cloud/region availability before deployment.
3. Keep collection vector dimensions aligned with the selected IBM watsonx.ai embedding model.
4. Use `astrapy` only as the implementation SDK; IBM watsonx.data is the product anchor.
5. Keep secrets outside source code and validate TLS/certificate handling.

## IBM references

- Add Astra DB service: https://www.ibm.com/docs/en/watsonxdata/saas?topic=watsonxdata-adding-astra-db-service
- watsonx.data availability: https://cloud.ibm.com/docs/watsonxdata?topic=watsonxdata-feature_parity_wxd
- Supported embedding models: https://www.ibm.com/docs/en/watsonx/saas?topic=models-supported-embedding
- Model lifecycle: https://www.ibm.com/docs/en/watsonx/saas?topic=model-foundation-lifecycle
