---
name: iceberg-table-management
description: Expert guidance for Apache Iceberg table lifecycle management on IBM watsonx.data — covers table DDL/DML via Presto SQL, partition strategy design, time-travel queries, snapshot management, schema evolution, compaction, and metadata optimization. Generates production-ready Python 3.12 scripts and SQL patterns following IBM building-blocks conventions.
---

# Apache Iceberg Table Management on IBM watsonx.data

## Purpose

Expert guidance for the full lifecycle of **Apache Iceberg** tables running on **IBM watsonx.data** — from initial schema design through partition strategies, time-travel queries, schema evolution, compaction scheduling, and metadata optimization.

## IBM Cloud Product Coverage

| IBM Cloud Product | Usage |
|---|---|
| IBM watsonx.data | Presto engine for Iceberg DDL/DML; REST API v2 for catalog management |
| Apache Iceberg | Open table format — snapshots, manifests, partition spec, schema evolution |
| IBM Cloud Object Storage | Iceberg data and metadata storage (`s3a://` paths) |
| IBM Cloud IAM | POST /identity/token (apikey grant) for API authentication |
| Apache Spark | Iceberg compaction and batch write jobs |

## Objective

Generate **production-ready Presto SQL statements and Python 3.12 scripts** that:

- Create Iceberg tables with correct partition specs and sort orders
- Perform DML: INSERT INTO, MERGE INTO (upsert), DELETE, UPDATE
- Execute time-travel queries using `FOR VERSION AS OF` and `FOR TIMESTAMP AS OF`
- Manage snapshots: expire, cherry-pick, rollback
- Evolve schemas safely: add/rename/drop columns following Iceberg schema evolution rules
- Run compaction via Presto `CALL system.rewrite_data_files()`
- Optimize manifests via `CALL system.rewrite_manifests()`
- Expire old snapshots via `CALL system.expire_snapshots()`

## Documentation Principles

- Always specify the fully-qualified table name: `catalog.schema.table`
- Use `WITH (format = 'PARQUET', partitioning = ARRAY['...'])` for CREATE TABLE
- Time-travel syntax on watsonx.data Presto: `SELECT * FROM table FOR VERSION AS OF <snapshot_id>`
- Compaction requires Presto >= 0.281 (watsonx.data engine level >= 1.1.0)
- Schema evolution: use `ALTER TABLE ... ADD COLUMN`, `RENAME COLUMN`, `DROP COLUMN` — never recreate
- Never use `INSERT OVERWRITE` — use `MERGE INTO` for upserts

## Procedure

### Phase 1: Table Design & DDL

```sql
-- Create a partitioned Iceberg table
CREATE TABLE iceberg_catalog.sales_schema.transactions (
    transaction_id   VARCHAR         NOT NULL,
    customer_id      VARCHAR,
    amount           DOUBLE,
    currency         VARCHAR(3),
    status           VARCHAR(20),
    created_at       TIMESTAMP(6)
)
WITH (
    format           = 'PARQUET',
    partitioning     = ARRAY['month(created_at)', 'status'],
    sorted_by        = ARRAY['customer_id ASC']
);
```

#### Partition Strategy Decision Tree

| Data Volume | Query Pattern | Recommended Partition |
|---|---|---|
| < 1 GB/day | Date range scans | `day(event_ts)` |
| 1-100 GB/day | Date + category filters | `month(event_ts)`, `category` |
| > 100 GB/day | High cardinality filtering | `bucket(customer_id, 64)`, `month(event_ts)` |
| Append-only events | Latest N days | `day(event_ts)` + `expire_snapshots` |

### Phase 2: DML Patterns

```sql
-- Upsert (MERGE INTO)
MERGE INTO iceberg_catalog.sales_schema.transactions AS target
USING (
    SELECT * FROM staging.new_transactions
) AS source
ON target.transaction_id = source.transaction_id
WHEN MATCHED AND source.status != target.status THEN
    UPDATE SET status = source.status, amount = source.amount
WHEN NOT MATCHED THEN
    INSERT (transaction_id, customer_id, amount, currency, status, created_at)
    VALUES (source.transaction_id, source.customer_id, source.amount,
            source.currency, source.status, source.created_at);

-- Targeted DELETE
DELETE FROM iceberg_catalog.sales_schema.transactions
WHERE status = 'CANCELLED' AND created_at < TIMESTAMP '2024-01-01 00:00:00';
```

### Phase 3: Time-Travel Queries

```sql
-- Query by snapshot ID
SELECT COUNT(*) FROM iceberg_catalog.sales_schema.transactions
FOR VERSION AS OF 8765432109876543210;

-- Query by timestamp (point-in-time)
SELECT * FROM iceberg_catalog.sales_schema.transactions
FOR TIMESTAMP AS OF TIMESTAMP '2024-06-15 12:00:00 UTC'
WHERE status = 'COMPLETED';

-- List all snapshots
SELECT * FROM iceberg_catalog.sales_schema."transactions$snapshots"
ORDER BY committed_at DESC;

-- List all files in current snapshot
SELECT * FROM iceberg_catalog.sales_schema."transactions$files"
LIMIT 100;
```

### Phase 4: Snapshot & Metadata Management

```sql
-- Expire snapshots older than 7 days (Presto procedure)
CALL iceberg_catalog.system.expire_snapshots(
    table => 'sales_schema.transactions',
    older_than => TIMESTAMP '2024-06-08 00:00:00 UTC',
    retain_last => 5
);

-- Rewrite small data files (compaction)
CALL iceberg_catalog.system.rewrite_data_files(
    table => 'sales_schema.transactions',
    strategy => 'sort',
    sort_order => 'customer_id ASC',
    options => MAP(ARRAY['min-file-size-bytes', 'max-file-size-bytes'],
                   ARRAY['134217728', '536870912'])
);

-- Rewrite manifest files
CALL iceberg_catalog.system.rewrite_manifests(
    table => 'sales_schema.transactions'
);
```

### Phase 5: Schema Evolution

```sql
-- Add a new nullable column (safe — always backward compatible)
ALTER TABLE iceberg_catalog.sales_schema.transactions
ADD COLUMN payment_method VARCHAR;

-- Rename a column (safe with Iceberg field IDs)
ALTER TABLE iceberg_catalog.sales_schema.transactions
RENAME COLUMN currency TO currency_code;

-- Widen a type (safe: INT -> BIGINT, FLOAT -> DOUBLE)
ALTER TABLE iceberg_catalog.sales_schema.transactions
ALTER COLUMN amount TYPE DOUBLE;

-- Drop a column (irreversible — verify no downstream consumers first)
ALTER TABLE iceberg_catalog.sales_schema.transactions
DROP COLUMN legacy_field;
```

### Phase 6: Python 3.12 Automation Script Pattern

```python
"""
iceberg_table_manager.py
IBM watsonx.data Iceberg table lifecycle automation — Python 3.12
"""
from __future__ import annotations

import os
import time
import logging
import requests

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger(__name__)

WXDATA_BASE_URL = os.environ["WXDATA_BASE_URL"]  # e.g. https://us-south.lakehouse.cloud.ibm.com/lakehouse/api/v2
WXDATA_CRN      = os.environ["WXDATA_CRN"]        # watsonx.data instance CRN
IBM_API_KEY     = os.environ["IBM_CLOUD_API_KEY"]
PRESTO_HOST     = os.environ["PRESTO_HOST"]        # https://<host>:8443


def get_iam_token(api_key: str) -> str:
    """Exchange IBM Cloud API key for a Bearer token."""
    resp = requests.post(
        "https://iam.cloud.ibm.com/identity/token",
        headers={"Content-Type": "application/x-www-form-urlencoded"},
        data={"grant_type": "urn:ibm:params:oauth:grant-type:apikey", "apikey": api_key},
        timeout=30,
    )
    resp.raise_for_status()
    return resp.json()["access_token"]


def run_presto_sql(token: str, sql: str, catalog: str = "iceberg_catalog") -> dict:
    """Submit a SQL statement to watsonx.data Presto REST API."""
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
        "AuthInstanceId": WXDATA_CRN,
    }
    payload = {"statement": sql, "catalog": catalog, "schema": "default"}
    resp = requests.post(f"{WXDATA_BASE_URL}/queries", headers=headers, json=payload, timeout=60)
    resp.raise_for_status()
    return resp.json()


def expire_old_snapshots(token: str, full_table: str, retain_last: int = 5) -> None:
    """Expire snapshots keeping only the last N."""
    sql = f"""
    CALL iceberg_catalog.system.expire_snapshots(
        table => '{full_table}',
        retain_last => {retain_last}
    )
    """
    result = run_presto_sql(token, sql)
    logger.info("expire_snapshots result: %s", result)


def compact_table(token: str, full_table: str) -> None:
    """Trigger compaction for a table."""
    sql = f"""
    CALL iceberg_catalog.system.rewrite_data_files(
        table => '{full_table}',
        strategy => 'binpack'
    )
    """
    result = run_presto_sql(token, sql)
    logger.info("rewrite_data_files result: %s", result)


if __name__ == "__main__":
    token = get_iam_token(IBM_API_KEY)
    expire_old_snapshots(token, "sales_schema.transactions")
    compact_table(token, "sales_schema.transactions")
    logger.info("Iceberg maintenance complete.")
```

## Common Pitfalls to Avoid

### Partition Pitfalls
- **Never use high-cardinality columns** (e.g., `transaction_id`) as partition keys — creates millions of small files
- **`hour()` partition on low-volume tables** creates too many partitions; prefer `day()` or `month()`
- **Changing partition spec** does not rewrite existing files — old files retain original partition layout

### DML Pitfalls
- **INSERT OVERWRITE** is not supported on Iceberg in Presto — always use `MERGE INTO` for upserts
- **Missing `NOT MATCHED THEN INSERT`** in MERGE — causes silent data loss when new records arrive
- **Deleting without filtering** a partition column results in a full table scan; always include partition predicates

### Schema Evolution Pitfalls
- **Renaming does NOT change the underlying field ID** — downstream Spark readers using field IDs remain unaffected
- **Dropping a column** is irreversible in Iceberg — data files still physically contain the column bytes
- **Type narrowing** (BIGINT -> INT) is NOT supported — only widening is safe

### Compaction Pitfalls
- **`rewrite_data_files` locks the table** during execution — schedule during off-peak hours
- **Do not expire snapshots** while a streaming job is actively writing — causes snapshot not found errors
- **Manifest rewrite** should run after bulk deletes to remove dangling manifest entries

## Quick Reference

### Iceberg Hidden Metadata Tables
| Table | Contents |
|---|---|
| `"table$snapshots"` | All snapshot metadata |
| `"table$files"` | All data files in current snapshot |
| `"table$manifests"` | All manifest files |
| `"table$partitions"` | Partition-level statistics |
| `"table$history"` | Snapshot history with parent chain |

### Supported Partition Transforms
| Transform | Syntax | Use Case |
|---|---|---|
| Identity | `col_name` | Low-cardinality string/int |
| Year | `year(ts_col)` | Annual partitioning |
| Month | `month(ts_col)` | Monthly partitioning |
| Day | `day(ts_col)` | Daily partitioning |
| Hour | `hour(ts_col)` | Hourly (high-volume only) |
| Bucket | `bucket(col, N)` | High-cardinality hash distribution |
| Truncate | `truncate(col, N)` | String prefix partitioning |

### watsonx.data Iceberg Catalog Naming
```
<catalog_name>.<schema_name>.<table_name>
```
- Default catalog for IBM COS: `iceberg_data` (set at bucket registration)
- Schema = Iceberg namespace
- Table names are case-insensitive

## Output Format

### Expected File Structure
```
iceberg-scripts/
├── create_tables.sql          # DDL for all tables with partitioning
├── dml_patterns.sql           # INSERT / MERGE / DELETE / UPDATE examples
├── time_travel.sql            # Time-travel query examples
├── maintenance.sql            # expire_snapshots / rewrite_data_files / rewrite_manifests
├── schema_evolution.sql       # ALTER TABLE ADD/RENAME/DROP COLUMN
└── iceberg_table_manager.py   # Python 3.12 automation script
```

## Usage Instructions

### To Use This Skill
1. Enable this skill in IBM Bob
2. Describe your Iceberg table use case: domain, volume, query patterns
3. Bob will generate DDL with appropriate partition strategy, DML patterns, and maintenance scripts

### Example Request
```
"Create an Iceberg table for IoT sensor events (10 million events/day) with time-travel capability and weekly compaction automation."
```

## Success Metrics

### Table Design
- Correct partition transforms applied to avoid small-file problem
- Sort order defined to minimize read-time I/O
- Schema uses Iceberg-native types (not Hive-compat types)

### Operations
- MERGE INTO correctly handles both matched and not-matched cases
- Time-travel queries use snapshot IDs or timestamps correctly
- Compaction scheduled with correct file size targets (128 MB min, 512 MB max)

### Maintenance
- Snapshot expiry retains at least 5 snapshots for rollback capability
- Manifest rewrite scheduled after bulk deletes
- All procedures use fully-qualified `catalog.schema.table` references

## End of Skill Document
