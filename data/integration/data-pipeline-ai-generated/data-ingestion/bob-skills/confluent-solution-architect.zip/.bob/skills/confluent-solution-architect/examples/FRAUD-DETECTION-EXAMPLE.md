# Fraud Detection Example

This example demonstrates how to use the Confluent Solution Architect skill to build a real-time fraud detection system.

## Business Problem

**Scenario:** A financial services company needs to detect fraudulent credit card transactions in real-time. They process approximately 10,000 transactions per minute and need to:

1. Identify high-velocity transaction patterns (multiple transactions in short time)
2. Detect unusual transaction amounts
3. Flag transactions from suspicious locations
4. Calculate risk scores for each transaction
5. Generate alerts for high-risk transactions

## User Request

```
"Build a real-time fraud detection system for credit card transactions. 
We need to detect:
- High transaction velocity (>10 transactions in 5 minutes per customer)
- Unusual amounts (>$5000 or <$0.01)
- Suspicious locations (different from customer's home location)
- Calculate risk scores and alert on scores >0.8"
```

## Generated Solution

### 1. Architecture

```mermaid
graph TB
    A[Transaction Source] --> B[transactions Topic]
    B --> C[Flink SQL: Velocity Check]
    B --> D[Flink SQL: Amount Check]
    B --> E[Flink SQL: Location Check]
    
    C --> F[fraud-alerts Topic]
    D --> F
    E --> F
    
    F --> G[Alert System]
    
    H[customer-profiles Topic] --> C
    H --> E
    
    style F fill:#ff6b6b
    style B fill:#4ecdc4
    style H fill:#95e1d3
```

### 2. Topic Design

#### transactions
**Purpose:** All credit card transactions
**Schema:**
```json
{
  "transaction_id": "string",
  "customer_id": "string",
  "amount": "decimal(10,2)",
  "merchant": "string",
  "merchant_category": "string",
  "location": "string",
  "transaction_time": "timestamp(3)"
}
```

#### fraud-alerts
**Purpose:** Detected fraud cases with risk scores
**Schema:**
```json
{
  "alert_id": "string",
  "customer_id": "string",
  "transaction_id": "string",
  "alert_type": "string",
  "risk_score": "decimal(5,2)",
  "alert_time": "timestamp(3)",
  "details": "string"
}
```

#### customer-profiles
**Purpose:** Customer behavior baselines
**Schema:**
```json
{
  "customer_id": "string",
  "home_location": "string",
  "avg_transaction_amount": "decimal(10,2)",
  "typical_merchants": "array<string>",
  "last_updated": "timestamp(3)"
}
```

### 3. Flink SQL Processing

#### Create Source Table
```sql
CREATE TABLE transactions (
  transaction_id STRING,
  customer_id STRING,
  amount DECIMAL(10, 2),
  merchant STRING,
  merchant_category STRING,
  location STRING,
  transaction_time TIMESTAMP(3),
  WATERMARK FOR transaction_time AS transaction_time - INTERVAL '5' SECONDS
) DISTRIBUTED BY (transaction_id) INTO 4 BUCKETS
WITH (
  'key.format' = 'json-registry',
  'value.format' = 'json-registry',
  'kafka.consumer.isolation-level' = 'read-uncommitted'
);
```

#### Create Destination Table
```sql
CREATE TABLE fraud_alerts (
  alert_id STRING,
  customer_id STRING,
  transaction_id STRING,
  alert_type STRING,
  risk_score DECIMAL(5, 2),
  alert_time TIMESTAMP(3),
  details STRING,
  PRIMARY KEY (alert_id) NOT ENFORCED
) WITH (
  'key.format' = 'json-registry',
  'value.format' = 'json-registry',
  'kafka.consumer.isolation-level' = 'read-uncommitted'
);
```

#### Velocity Check Job
```sql
INSERT INTO fraud_alerts
SELECT 
  CONCAT('ALERT-', CAST(UNIX_TIMESTAMP() AS STRING), '-', transaction_id) as alert_id,
  customer_id,
  transaction_id,
  'HIGH_VELOCITY' as alert_type,
  CAST(velocity_count AS DECIMAL(5,2)) / 10.0 as risk_score,
  transaction_time as alert_time,
  CONCAT('Customer made ', CAST(velocity_count AS STRING), ' transactions in 5 minutes') as details
FROM (
  SELECT 
    transaction_id,
    customer_id,
    transaction_time,
    COUNT(*) OVER (
      PARTITION BY customer_id 
      ORDER BY transaction_time 
      RANGE BETWEEN INTERVAL '5' MINUTES PRECEDING AND CURRENT ROW
    ) as velocity_count
  FROM transactions
)
WHERE velocity_count > 10;
```

#### Amount Anomaly Check Job
```sql
INSERT INTO fraud_alerts
SELECT 
  CONCAT('ALERT-', CAST(UNIX_TIMESTAMP() AS STRING), '-', transaction_id) as alert_id,
  customer_id,
  transaction_id,
  'UNUSUAL_AMOUNT' as alert_type,
  CASE 
    WHEN amount > 5000 THEN 0.9
    WHEN amount < 0.01 THEN 0.7
    ELSE 0.5
  END as risk_score,
  transaction_time as alert_time,
  CONCAT('Unusual amount: $', CAST(amount AS STRING)) as details
FROM transactions
WHERE amount > 5000 OR amount < 0.01;
```

#### Location Anomaly Check Job
```sql
INSERT INTO fraud_alerts
SELECT 
  CONCAT('ALERT-', CAST(UNIX_TIMESTAMP() AS STRING), '-', t.transaction_id) as alert_id,
  t.customer_id,
  t.transaction_id,
  'SUSPICIOUS_LOCATION' as alert_type,
  0.85 as risk_score,
  t.transaction_time as alert_time,
  CONCAT('Transaction from ', t.location, ' (home: ', cp.home_location, ')') as details
FROM transactions t
JOIN customer_profiles cp ON t.customer_id = cp.customer_id
WHERE t.location <> cp.home_location;
```

### 4. Sample Data

#### Sample Transactions (Normal)
```json
[
  {
    "transaction_id": "TXN-001",
    "customer_id": "CUST-12345",
    "amount": 45.99,
    "merchant": "Coffee Shop",
    "merchant_category": "Food & Beverage",
    "location": "US-CA-SF",
    "transaction_time": 1704067200000
  },
  {
    "transaction_id": "TXN-002",
    "customer_id": "CUST-12345",
    "amount": 125.50,
    "merchant": "Gas Station",
    "merchant_category": "Fuel",
    "location": "US-CA-SF",
    "transaction_time": 1704070800000
  }
]
```

#### Sample Transactions (Fraudulent)
```json
[
  {
    "transaction_id": "TXN-FRAUD-001",
    "customer_id": "CUST-12345",
    "amount": 7500.00,
    "merchant": "Electronics Store",
    "merchant_category": "Electronics",
    "location": "US-NY-NYC",
    "transaction_time": 1704074400000
  },
  {
    "transaction_id": "TXN-FRAUD-002",
    "customer_id": "CUST-12345",
    "amount": 0.001,
    "merchant": "Online Service",
    "merchant_category": "Digital",
    "location": "US-CA-SF",
    "transaction_time": 1704074460000
  }
]
```

#### Sample Customer Profiles
```json
[
  {
    "customer_id": "CUST-12345",
    "home_location": "US-CA-SF",
    "avg_transaction_amount": 85.50,
    "typical_merchants": ["Coffee Shop", "Gas Station", "Grocery Store"],
    "last_updated": 1704067200000
  }
]
```

### 5. Python Producer

```python
from confluent_kafka import Producer
from confluent_kafka.schema_registry import SchemaRegistryClient
from confluent_kafka.schema_registry.json_schema import JSONSerializer
from confluent_kafka.serialization import SerializationContext, MessageField
import json
import os
from datetime import datetime
from dotenv import load_dotenv

load_dotenv()

# Schema Registry client
sr_client = SchemaRegistryClient({
    'url': os.getenv('SCHEMA_REGISTRY_URL'),
    'basic.auth.user.info': f"{os.getenv('SCHEMA_REGISTRY_API_KEY')}:{os.getenv('SCHEMA_REGISTRY_API_SECRET')}"
})

# Retrieve schemas
key_schema = sr_client.get_latest_version('transactions-key').schema
value_schema = sr_client.get_latest_version('transactions-value').schema

# Serializers
key_serializer = JSONSerializer(key_schema.schema_str, sr_client)
value_serializer = JSONSerializer(value_schema.schema_str, sr_client)

# Producer config
producer = Producer({
    'bootstrap.servers': os.getenv('KAFKA_BOOTSTRAP_SERVERS'),
    'security.protocol': 'SASL_SSL',
    'sasl.mechanisms': 'PLAIN',
    'sasl.username': os.getenv('KAFKA_API_KEY'),
    'sasl.password': os.getenv('KAFKA_API_SECRET')
})

def delivery_callback(err, msg):
    if err:
        print(f"❌ Failed: {err}")
    else:
        print(f"✅ Delivered → Partition {msg.partition()} @ Offset {msg.offset()}")

# Load and produce transactions
with open('sample-transactions.json', 'r') as f:
    transactions = json.load(f)

success_count = 0
failure_count = 0

for txn in transactions:
    try:
        key = {"transaction_id": txn["transaction_id"]}
        value = {k: v for k, v in txn.items() if k != "transaction_id"}
        
        producer.produce(
            topic='transactions',
            key=key_serializer(key, SerializationContext('transactions', MessageField.KEY)),
            value=value_serializer(value, SerializationContext('transactions', MessageField.VALUE)),
            callback=delivery_callback
        )
        success_count += 1
    except Exception as e:
        print(f"❌ Error: {e}")
        failure_count += 1

producer.flush()
print(f"\n📊 Summary: {success_count} successful, {failure_count} failed")
```

### 6. Testing Queries

#### Query 1: View Recent Transactions
```sql
SELECT 
  transaction_id,
  customer_id,
  amount,
  merchant,
  location,
  transaction_time
FROM transactions
ORDER BY transaction_time DESC
LIMIT 20;
```

**Expected Output:**
| transaction_id | customer_id | amount | merchant | location | transaction_time |
|---------------|-------------|--------|----------|----------|------------------|
| TXN-FRAUD-002 | CUST-12345 | 0.001 | Online Service | US-CA-SF | 2024-01-01 12:01:00 |
| TXN-FRAUD-001 | CUST-12345 | 7500.00 | Electronics Store | US-NY-NYC | 2024-01-01 12:00:00 |

**Verification:** ✅ Transactions flowing from producer

#### Query 2: View Fraud Alerts
```sql
SELECT 
  alert_id,
  customer_id,
  transaction_id,
  alert_type,
  risk_score,
  alert_time,
  details
FROM fraud_alerts
ORDER BY alert_time DESC, risk_score DESC
LIMIT 20;
```

**Expected Output:**
| alert_id | customer_id | transaction_id | alert_type | risk_score | alert_time | details |
|----------|-------------|----------------|------------|------------|------------|---------|
| ALERT-... | CUST-12345 | TXN-FRAUD-001 | UNUSUAL_AMOUNT | 0.90 | 2024-01-01 12:00:00 | Unusual amount: $7500.00 |
| ALERT-... | CUST-12345 | TXN-FRAUD-001 | SUSPICIOUS_LOCATION | 0.85 | 2024-01-01 12:00:00 | Transaction from US-NY-NYC (home: US-CA-SF) |

**Verification:** ✅ Fraud detection logic working correctly

#### Query 3: High-Risk Alerts Only
```sql
SELECT 
  customer_id,
  COUNT(*) as alert_count,
  AVG(risk_score) as avg_risk_score,
  MAX(risk_score) as max_risk_score
FROM fraud_alerts
WHERE risk_score > 0.8
GROUP BY customer_id
ORDER BY max_risk_score DESC;
```

**Expected Output:**
| customer_id | alert_count | avg_risk_score | max_risk_score |
|-------------|-------------|----------------|----------------|
| CUST-12345 | 2 | 0.875 | 0.90 |

**Verification:** ✅ High-risk filtering working

#### Query 4: Alert Type Distribution
```sql
SELECT 
  alert_type,
  COUNT(*) as count,
  AVG(risk_score) as avg_risk_score
FROM fraud_alerts
GROUP BY alert_type
ORDER BY count DESC;
```

**Expected Output:**
| alert_type | count | avg_risk_score |
|------------|-------|----------------|
| UNUSUAL_AMOUNT | 2 | 0.80 |
| SUSPICIOUS_LOCATION | 1 | 0.85 |
| HIGH_VELOCITY | 0 | NULL |

**Verification:** ✅ Multiple detection patterns working

### 7. Deployment Steps

#### Step 1: Setup Infrastructure
```bash
cd terraform
terraform init
terraform apply -auto-approve
```

#### Step 2: Setup Python Environment
```bash
cd ../python
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

#### Step 3: Produce Test Data
```bash
# Normal transactions
python producers/produce_messages.py --file sample-transactions-normal.json

# Wait 30 seconds for processing

# Fraudulent transactions
python producers/produce_messages.py --file sample-transactions-fraud.json
```

#### Step 4: Validate Results
Use the Flink SQL queries above in Confluent Cloud Console or CLI.

#### Step 5: Cleanup
```bash
cd ../terraform
terraform destroy -auto-approve
```

### 8. Expected Results

After producing test data, you should see:

1. **Normal Transactions:** Processed without alerts
2. **High Amount Transaction ($7500):** Generates UNUSUAL_AMOUNT alert with risk_score 0.9
3. **Micro Transaction ($0.001):** Generates UNUSUAL_AMOUNT alert with risk_score 0.7
4. **Location Mismatch:** Generates SUSPICIOUS_LOCATION alert with risk_score 0.85
5. **High Velocity:** If >10 transactions in 5 minutes, generates HIGH_VELOCITY alert

### 9. Business Value

This solution provides:

- **Real-time Detection:** Fraud identified within seconds
- **Multiple Patterns:** Velocity, amount, and location checks
- **Risk Scoring:** Prioritize high-risk alerts
- **Scalability:** Handles 10,000+ transactions/minute
- **Flexibility:** Easy to add new detection patterns

### 10. Next Steps

To enhance this solution:

1. **Add Machine Learning:** Integrate ML models for advanced pattern detection
2. **Customer Segmentation:** Different thresholds for different customer types
3. **Historical Analysis:** Compare against customer's historical patterns
4. **Merchant Reputation:** Factor in merchant fraud history
5. **Device Fingerprinting:** Track device IDs for additional validation
6. **Geolocation Distance:** Calculate distance between transactions
7. **Time-of-Day Patterns:** Flag unusual transaction times

## Summary

This example demonstrates how the Confluent Solution Architect skill generates a complete, production-ready fraud detection system with:

✅ Proper topic design aligned with business domain
✅ Multiple Flink SQL jobs for different fraud patterns
✅ Schema-aware Python producers
✅ Comprehensive testing procedures
✅ Clear deployment instructions
✅ Business value documentation

The generated solution is ready to deploy and can be customized for specific business requirements.