# Building Blocks Explorer — Bob mode

You've unzipped the bundle. The actual mode config lives in the hidden `.bob/` directory next to this README.

## Quick start

1. Open this folder as your Bob workspace.
2. Select **🧱 IBM Building Blocks Explorer** in Bob's mode picker.
3. Try: *"What building blocks are available?"* or describe a use case you want to build.

## What's in `.bob/`

- `custom_modes.yaml` — the mode definition Bob loads
- `mcp.json` — points Bob at the Building Blocks MCP server (read-only, public data, no auth)
- `rules-building-blocks/` — the SDLC workflow Bob follows

## What this mode does

Guides you through Discover → Clarify → Design → Confirm → Hand-off. When you accept a recommendation, it downloads the recommended builder Bob mode and merges it into this `.bob/` folder. After reloading Bob, the new mode appears in the picker — same workspace, no switching folders.

The MCP server: `https://building-blocks-mcp.23rbzktsxcbt.us-south.codeengine.appdomain.cloud/mcp`
